import React from 'react';
import _ from 'lodash';
import Task from './Task';

const TaskList = ({tasks, setTasks }) => {

  const handleRemoveTask = (id) => {
    setTasks(tasks.filter((task) => task.id !== id));
  };

  return (
    <React.Fragment>
      <div className="task-list">
        {!_.isEmpty(tasks) ? (
         tasks.map((task) => (
            <Task key={task.id} {...task} handleRemoveTask={handleRemoveTask} />
          ))
        ) : (
          <p className="message">No tasks available. Please add some books.</p>
        )}
      </div>
    </React.Fragment>
  );
};



export default TaskList;