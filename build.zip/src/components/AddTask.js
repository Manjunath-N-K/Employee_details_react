import React from 'react';

import TaskForm from './TaskForm';

const AddTask = ({history,tasks,setTasks}) => {
  const handleOnSubmit = (task) => {
    setTasks([task,...tasks]);
    history.push('/');
    console.log(task);
  };

  return (
    <React.Fragment>
      <TaskForm handleOnSubmit={handleOnSubmit} />
    </React.Fragment>
  );
};

export default AddTask;