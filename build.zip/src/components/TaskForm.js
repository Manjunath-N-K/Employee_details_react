import React, { useState } from 'react';
import { Form, Button } from 'react-bootstrap';
import { v4 as uuidv4 } from 'uuid';


const TaskForm = (props) => {
  const [task, setTask] = useState({
    taskname: props.task ? props.task.taskname : '',
    title: props.task ? props.task.title : '',
    time: props.task ? props.task.time : '',
    date: props.task ? props.task.date : ''
   
  });

  

  const [errorMsg, setErrorMsg] = useState('');
  const { taskname, title, time,date } = task;

  const handleOnSubmit = (event) => {
    event.preventDefault();
    const values = [ taskname, title, time,date];
    let errorMsg = '';

    const allFieldsFilled = values.every((field) => {
      const value = `${field}`.trim();
      return value !== '' && value !== '0';
    });

    if (allFieldsFilled) {
      const task = {
       id: uuidv4(),
        taskname,
        title,
        time, 
        date
      };
      props.handleOnSubmit(task);
    } else {
      errorMsg = 'Please fill out all the fields.';
    }
    setErrorMsg(errorMsg);
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    switch (name) { 
     
      default:
        setTask((prevState) => ({
          ...prevState,
          [name]: value
        }));
    }
  };

  return (
    <div className="main-form">
      {errorMsg && <p className="errorMsg">{errorMsg}</p>}
      <Form onSubmit={handleOnSubmit}>
        <Form.Group controlId="name">
          <Form.Label>Task Name</Form.Label>
          <Form.Control
            className="input-control"
            type="text"
            name="taskname"
            value={taskname}
            placeholder="Enter name of task"
            onChange={handleInputChange}
          />
        </Form.Group>
        <Form.Group controlId="title">
          <Form.Label>Book summary</Form.Label>
          <Form.Control
            className="input-control"
            type="text"
            name="title"
            value={title}
            placeholder="Enter the summary"
            onChange={handleInputChange}
          />
        </Form.Group>
        
        <Form.Group controlId="date">
          <Form.Label>Date</Form.Label>
          <Form.Control
            className="input-control"
            type="date"
           name="date"
          value={date}
            placeholder="Enter the Date"
            onChange={handleInputChange}
          /> 
        </Form.Group>

        <Form.Group controlId="time">
          <Form.Label>Time</Form.Label>
          <Form.Control
            className="input-control"
            type="time"
            step="1"
            name="time"
            
            value={time}
            placeholder="Enter the time"
            onChange={handleInputChange}
          />
           
        </Form.Group>
        <Button variant="primary" type="submit" className="submit-btn">
          Submit
        </Button>
      </Form>
    </div>
  );
};






export default TaskForm;