import React from 'react';
import { BrowserRouter, Switch, Route } from 'react-router-dom';
import Header from '../components/Header';
import AddTask from '../components/AddTask';
import TaskList from '../components/TaskList';
import useLocalStorage from '../hooks/useLocalStorage';
import EditTask from '../components/EditTask';



const AppRouter = () => {
   const [tasks, setTasks] = useLocalStorage('tasks', []);
  return (
    <BrowserRouter>
      <div>
        <Header />
        <div className="main-content">
          <Switch>
            <Route
              render={(props) => (
                <TaskList {...props} tasks={tasks} setTasks={setTasks} />
              )}
              path="/"
              exact={true}
            />
            <Route
              render={(props) => (
                <AddTask {...props} tasks={tasks} setTasks={setTasks} />
              )}
              path="/add"
            />
            <Route
              render={(props) => (
                <EditTask {...props} tasks={tasks} setTasks={setTasks} />
              )}
              path="/edit/:id"
            />
           
          </Switch>
        </div>
      </div>
    </BrowserRouter>
  );
};

export default AppRouter;